/*global angular*/
import periodTag from './period_tag';
export default angular.module('apps/sentinl.periodTag', []).directive(periodTag.name, periodTag);
