/*global angular*/
import consoleAction from './console_action';
export default angular.module('apps/sentinl.consoleAction', []).directive(consoleAction.name, consoleAction);
