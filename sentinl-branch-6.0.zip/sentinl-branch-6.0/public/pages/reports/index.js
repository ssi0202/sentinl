/* global angular */
import Reports from './reports.controller';

export default angular.module('apps/sentinl.reportsPage', []).controller('ReportsController', Reports);
