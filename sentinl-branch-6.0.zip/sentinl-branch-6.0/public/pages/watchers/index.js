/* global angular */
import Watchers from './watchers.controller';

export default angular.module('apps/sentinl.watchersPage', []).controller('WatchersController', Watchers);
