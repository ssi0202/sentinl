/* global angular */
import Alarms from './alarms.controller';

export default angular.module('apps/sentinl.alarmsPage', []).controller('AlarmsController', Alarms);
