/*global angular*/
import navMenu from './nav_menu';

export default angular.module('apps/sentinl.navMenu', []).factory('navMenu', navMenu);
