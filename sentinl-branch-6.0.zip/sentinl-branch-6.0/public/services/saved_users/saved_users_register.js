export default function savedUsersRegister(savedUsers) {
  return savedUsers;
}
