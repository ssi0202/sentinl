export default function savedWatchersRegister(savedWatchers) {
  return savedWatchers;
}
