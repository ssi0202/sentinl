/* global angular */

import Confirm from './confirm_message.controller';

export default angular.module('apps/sentinl.confirmMessage', [])
.controller('ConfirmMessageController', Confirm);
